package com.example.update

import android.content.Context
import android.content.Intent
import android.net.Uri

data class AppUpdateInfo(
    val currentVersion: String = "1.0.0",
    val latestVersion: String = "1.1.0",
    val isUpdateAvailable: Boolean = false,
    val releaseNotesBangla: String = "নতুন নাইট কার্ফিউ লক ও অডিও কুরআন মডিউল যুক্ত করা হয়েছে।",
    val downloadUrl: String = "https://github.com/akimul343-ui"
)

class AppUpdateChecker(private val context: Context) {

    fun checkForUpdates(): AppUpdateInfo {
        // Returns version details and check status
        val current = "1.0.0"
        return AppUpdateInfo(
            currentVersion = current,
            latestVersion = "1.0.0",
            isUpdateAvailable = false,
            releaseNotesBangla = "আপনার অ্যাপটি সর্বশেষ নিরাপদ সংস্করণে আপডেট করা রয়েছে।",
            downloadUrl = "https://github.com/akimul343-ui"
        )
    }

    fun openUpdatePage(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // ignore
        }
    }
}
