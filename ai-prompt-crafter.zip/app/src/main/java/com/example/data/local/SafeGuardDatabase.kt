package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface LockLogDao {
    @Query("SELECT * FROM lock_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentLogs(): Flow<List<LockLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LockLogEntity)

    @Query("DELETE FROM lock_logs")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM lock_logs")
    fun getTotalLogCount(): Flow<Int>
}

@Database(
    entities = [LockLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SafeGuardDatabase : RoomDatabase() {
    abstract fun lockLogDao(): LockLogDao

    companion object {
        @Volatile
        private var INSTANCE: SafeGuardDatabase? = null

        fun getDatabase(context: Context): SafeGuardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SafeGuardDatabase::class.java,
                    "safeguard_lock.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
