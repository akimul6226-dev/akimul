package com.example.curfew

import android.content.Context
import android.content.SharedPreferences
import java.util.Calendar

data class CurfewConfig(
    val isEnabled: Boolean = false,
    val startHour: Int = 23,     // 11 PM
    val startMinute: Int = 0,
    val endHour: Int = 4,        // 4 AM
    val endMinute: Int = 0,
    val isStrictUnbreakableLock: Boolean = false, // "খুলবে না কিন্তু চাইলেও যেন খুলতে পারে না ঠিক ওই টাইম শেষ হওয়ার পর যেন ফোন খুলে"
    val emergencyPinRequired: Boolean = true,
    val reasonMessage: String = "নির্ধারিত সময় লক রয়েছে। আত্মনিয়ন্ত্রণ ও ইবাদতের জন্য ফোন ব্যবহার বন্ধ রাখা হয়েছে।"
)

class CurfewManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("safeguard_curfew_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CURFEW_ENABLED = "curfew_enabled"
        private const val KEY_START_HOUR = "curfew_start_hour"
        private const val KEY_START_MINUTE = "curfew_start_minute"
        private const val KEY_END_HOUR = "curfew_end_hour"
        private const val KEY_END_MINUTE = "curfew_end_minute"
        private const val KEY_STRICT_LOCK = "curfew_strict_lock"
        private const val KEY_MESSAGE = "curfew_message"
        private const val KEY_TEMP_EMERGENCY_UNLOCK_UNTIL = "curfew_temp_unlock_until"
    }

    fun getCurfewConfig(): CurfewConfig {
        return CurfewConfig(
            isEnabled = prefs.getBoolean(KEY_CURFEW_ENABLED, false),
            startHour = prefs.getInt(KEY_START_HOUR, 23),
            startMinute = prefs.getInt(KEY_START_MINUTE, 0),
            endHour = prefs.getInt(KEY_END_HOUR, 4),
            endMinute = prefs.getInt(KEY_END_MINUTE, 0),
            isStrictUnbreakableLock = prefs.getBoolean(KEY_STRICT_LOCK, false),
            emergencyPinRequired = true,
            reasonMessage = prefs.getString(
                KEY_MESSAGE,
                "নির্ধারিত সময় লক রয়েছে। আত্মনিয়ন্ত্রণ ও ইবাদতের জন্য ফোন ব্যবহার বন্ধ রাখা হয়েছে।"
            ) ?: ""
        )
    }

    fun saveCurfewConfig(config: CurfewConfig) {
        prefs.edit()
            .putBoolean(KEY_CURFEW_ENABLED, config.isEnabled)
            .putInt(KEY_START_HOUR, config.startHour)
            .putInt(KEY_START_MINUTE, config.startMinute)
            .putInt(KEY_END_HOUR, config.endHour)
            .putInt(KEY_END_MINUTE, config.endMinute)
            .putBoolean(KEY_STRICT_LOCK, config.isStrictUnbreakableLock)
            .putString(KEY_MESSAGE, config.reasonMessage)
            .apply()
    }

    /**
     * Checks if current local time falls into active curfew lockdown period.
     * Supports exact minute intervals (e.g., 6:40 to 6:41, or 23:15 to 04:30).
     */
    fun isCurfewCurrentlyActive(): Boolean {
        val config = getCurfewConfig()
        if (!config.isEnabled) return false

        // If strict unbreakable lock is ON, emergency unlock is completely disallowed!
        if (!config.isStrictUnbreakableLock) {
            val tempUnlockUntil = prefs.getLong(KEY_TEMP_EMERGENCY_UNLOCK_UNTIL, 0L)
            if (System.currentTimeMillis() < tempUnlockUntil) {
                return false
            }
        }

        val cal = Calendar.getInstance()
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val currentMinute = cal.get(Calendar.MINUTE)
        val currentTotalMinutes = currentHour * 60 + currentMinute

        val startTotalMinutes = config.startHour * 60 + config.startMinute
        val endTotalMinutes = config.endHour * 60 + config.endMinute

        return if (startTotalMinutes == endTotalMinutes) {
            false
        } else if (startTotalMinutes < endTotalMinutes) {
            // Same-day curfew (e.g. 6:40 to 6:41, or 14:00 to 18:00)
            currentTotalMinutes in startTotalMinutes until endTotalMinutes
        } else {
            // Overnight curfew spanning midnight (e.g. 23:00 to 04:00)
            currentTotalMinutes >= startTotalMinutes || currentTotalMinutes < endTotalMinutes
        }
    }

    /**
     * Returns remaining seconds until curfew unlock time.
     */
    fun getRemainingSeconds(): Long {
        val config = getCurfewConfig()
        val cal = Calendar.getInstance()
        val currentHour = cal.get(Calendar.HOUR_OF_DAY)
        val currentMinute = cal.get(Calendar.MINUTE)
        val currentSecond = cal.get(Calendar.SECOND)

        val targetCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, config.endHour)
            set(Calendar.MINUTE, config.endMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If target is in the past for today, it ends tomorrow
        val currentTotalSeconds = (currentHour * 3600) + (currentMinute * 60) + currentSecond
        val endTotalSeconds = (config.endHour * 3600) + (config.endMinute * 60)

        val diffSeconds = if (endTotalSeconds > currentTotalSeconds) {
            endTotalSeconds - currentTotalSeconds
        } else {
            (24 * 3600) - currentTotalSeconds + endTotalSeconds
        }

        return diffSeconds.toLong().coerceAtLeast(0L)
    }

    fun grantEmergencyUnlock(durationMinutes: Int = 10) {
        val config = getCurfewConfig()
        if (config.isStrictUnbreakableLock) {
            // Unbreakable lock cannot be bypassed!
            return
        }
        val unlockUntil = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)
        prefs.edit().putLong(KEY_TEMP_EMERGENCY_UNLOCK_UNTIL, unlockUntil).apply()
    }

    fun formatTimeString(hour: Int, minute: Int): String {
        val isPm = hour >= 12
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        val period = if (isPm) "PM" else "AM"
        val minStr = String.format("%02d", minute)
        return "$displayHour:$minStr $period"
    }

    fun formatBanglaTimeString(hour: Int, minute: Int): String {
        val period = when {
            hour in 4..11 -> "সকাল"
            hour in 12..15 -> "দুপুর"
            hour in 16..17 -> "বিকাল"
            hour in 18..19 -> "সন্ধ্যা"
            else -> "রাত"
        }
        val displayHour = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        val minStr = String.format("%02d", minute)
        return "$period $displayHour:$minStr"
    }
}
