package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.islamic.AudioPlaybackStatus
import com.example.ui.components.BedtimeLockTab
import com.example.ui.components.FeatureCatalogSection
import com.example.ui.components.FullscreenCurfewOverlay
import com.example.ui.components.IslamicRecoveryTab
import com.example.ui.components.MetricCard
import com.example.ui.components.PinDialog
import com.example.ui.components.SettingsTab
import com.example.ui.components.SetupPinDialog
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.util.AppLanguage
import com.example.util.AppStrings

@Composable
fun SafeGuardScreen(
    viewModel: SafeGuardViewModel,
    onRequestDeviceAdmin: () -> Unit
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val isCurfewLockActive by viewModel.isCurfewLockActive.collectAsState()
    val curfewConfig by viewModel.curfewConfig.collectAsState()
    val isDeviceAdminActive by viewModel.isDeviceAdminActive.collectAsState()
    val isPinConfigured by viewModel.isPinConfigured.collectAsState()
    val pendingPinAction by viewModel.pendingPinAction.collectAsState()
    val showSetupPinDialog by viewModel.showSetupPinDialog.collectAsState()
    val statusBanner by viewModel.statusBanner.collectAsState()
    val playerState by viewModel.playerState.collectAsState()
    val selectedAudioMode by viewModel.selectedAudioMode.collectAsState()
    val updateInfo by viewModel.updateInfo.collectAsState()
    val appLanguage by viewModel.appLanguage.collectAsState()
    val lockLogs by viewModel.lockLogs.collectAsState()

    val isBangla = appLanguage == AppLanguage.BANGLA

    Scaffold(
        topBar = {
            TopHeaderBar(
                isBangla = isBangla,
                isCurfewActive = isCurfewLockActive,
                isDeviceAdminActive = isDeviceAdminActive,
                onToggleLanguage = {
                    val next = if (appLanguage == AppLanguage.BANGLA) AppLanguage.ENGLISH else AppLanguage.BANGLA
                    viewModel.setLanguage(next)
                }
            )
        },
        bottomBar = {
            Column {
                // Persistent Mini Audio Bar if playing/paused
                if (playerState.status != AudioPlaybackStatus.IDLE && playerState.activeSurahNumber != null) {
                    MiniAudioPlayerBar(
                        playerState = playerState,
                        onPlayPause = {
                            val surah = viewModel.surahs.find { it.number == playerState.activeSurahNumber }
                            if (surah != null) {
                                viewModel.onPlaySurah(surah, playerState.activeAudioMode)
                            }
                        },
                        onStop = { viewModel.quranAudioManager.stopPlayback() },
                        onClick = { viewModel.selectTab(SafeGuardTab.ISLAMIC_RECOVERY) }
                    )
                }

                // Main Bottom Navigation
                NavigationBar(
                    containerColor = CyberSurface,
                    contentColor = CyberPrimary,
                    modifier = Modifier.border(1.dp, CyberBorder)
                ) {
                    NavigationBarItem(
                        selected = currentTab == SafeGuardTab.OVERVIEW,
                        onClick = { viewModel.selectTab(SafeGuardTab.OVERVIEW) },
                        icon = {
                            Icon(
                                Icons.Default.Shield,
                                contentDescription = "Shield",
                                tint = if (currentTab == SafeGuardTab.OVERVIEW) CyberPrimary else CyberTextMuted
                            )
                        },
                        label = {
                            Text(
                                text = AppStrings.t("tab_overview", isBangla),
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == SafeGuardTab.OVERVIEW) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted,
                            indicatorColor = CyberPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_overview")
                    )

                    NavigationBarItem(
                        selected = currentTab == SafeGuardTab.BEDTIME_LOCK,
                        onClick = { viewModel.selectTab(SafeGuardTab.BEDTIME_LOCK) },
                        icon = {
                            Icon(
                                Icons.Default.Bedtime,
                                contentDescription = "Curfew Lock",
                                tint = if (currentTab == SafeGuardTab.BEDTIME_LOCK) CyberWarning else CyberTextMuted
                            )
                        },
                        label = {
                            Text(
                                text = AppStrings.t("tab_bedtime", isBangla),
                                fontSize = 10.sp,
                                fontWeight = if (currentTab == SafeGuardTab.BEDTIME_LOCK) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberWarning,
                            selectedTextColor = CyberWarning,
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted,
                            indicatorColor = CyberWarning.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_bedtime")
                    )

                    NavigationBarItem(
                        selected = currentTab == SafeGuardTab.ISLAMIC_RECOVERY,
                        onClick = { viewModel.selectTab(SafeGuardTab.ISLAMIC_RECOVERY) },
                        icon = {
                            Icon(
                                Icons.Default.MenuBook,
                                contentDescription = "Quran & Guide",
                                tint = if (currentTab == SafeGuardTab.ISLAMIC_RECOVERY) CyberSecondary else CyberTextMuted
                            )
                        },
                        label = {
                            Text(
                                text = AppStrings.t("tab_quran", isBangla),
                                fontSize = 10.sp,
                                fontWeight = if (currentTab == SafeGuardTab.ISLAMIC_RECOVERY) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberSecondary,
                            selectedTextColor = CyberSecondary,
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted,
                            indicatorColor = CyberSecondary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_islamic")
                    )

                    NavigationBarItem(
                        selected = currentTab == SafeGuardTab.SETTINGS,
                        onClick = { viewModel.selectTab(SafeGuardTab.SETTINGS) },
                        icon = {
                            Icon(
                                Icons.Default.Tune,
                                contentDescription = "Settings",
                                tint = if (currentTab == SafeGuardTab.SETTINGS) CyberPrimary else CyberTextMuted
                            )
                        },
                        label = {
                            Text(
                                text = AppStrings.t("tab_settings", isBangla),
                                fontSize = 10.sp,
                                fontWeight = if (currentTab == SafeGuardTab.SETTINGS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted,
                            indicatorColor = CyberPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("tab_settings")
                    )
                }
            }
        },
        containerColor = CyberBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentTab) {
                SafeGuardTab.OVERVIEW -> {
                    OverviewTabContent(
                        isBangla = isBangla,
                        curfewConfig = curfewConfig,
                        isCurfewActive = isCurfewLockActive,
                        isDeviceAdminActive = isDeviceAdminActive,
                        isPinConfigured = isPinConfigured,
                        curfewManager = viewModel.curfewManager,
                        onUpdateCurfewConfig = { viewModel.updateCurfewConfig(it) },
                        onQuickTestLock = { viewModel.testOneMinuteLock() },
                        onLockScreenNow = { viewModel.lockScreenNow() },
                        onRequestActivateAdmin = onRequestDeviceAdmin,
                        onNavigateTab = { viewModel.selectTab(it) }
                    )
                }
                SafeGuardTab.BEDTIME_LOCK -> {
                    BedtimeLockTab(
                        curfewConfig = curfewConfig,
                        isLockCurrentlyActive = isCurfewLockActive,
                        onUpdateConfig = { viewModel.updateCurfewConfig(it) },
                        onRequestEmergencyOverride = { viewModel.requestEmergencyCurfewOverride() }
                    )
                }
                SafeGuardTab.ISLAMIC_RECOVERY -> {
                    IslamicRecoveryTab(
                        surahs = viewModel.surahs,
                        advices = viewModel.antiAddictionAdvices,
                        hadithBooks = viewModel.hadithBooks,
                        islamicPoems = viewModel.islamicPoems,
                        playerState = playerState,
                        selectedAudioMode = selectedAudioMode,
                        onSetAudioMode = { viewModel.setAudioMode(it) },
                        onPlaySurah = { surah, mode -> viewModel.onPlaySurah(surah, mode) },
                        onDownloadSurah = { surah, mode -> viewModel.onDownloadSurah(surah, mode) },
                        onDeleteSurah = { surahNumber, mode -> viewModel.onDeleteDownloadedSurah(surahNumber, mode) }
                    )
                }
                SafeGuardTab.SETTINGS -> {
                    SettingsTab(
                        isBangla = isBangla,
                        isDeviceAdminActive = isDeviceAdminActive,
                        onRequestActivateAdmin = onRequestDeviceAdmin,
                        onRequestDeactivateAdmin = { viewModel.requestDeactivateAdmin() },
                        isPinConfigured = isPinConfigured,
                        onRequestChangePin = { viewModel.requestChangePin() },
                        currentLanguage = appLanguage,
                        onToggleLanguage = {
                            val next = if (appLanguage == AppLanguage.BANGLA) AppLanguage.ENGLISH else AppLanguage.BANGLA
                            viewModel.setLanguage(next)
                        },
                        updateInfo = updateInfo,
                        onCheckUpdate = { viewModel.checkAppUpdateNow() },
                        onOpenUpdateLink = { viewModel.openUpdateLink() },
                        lockLogs = lockLogs,
                        onRequestClearLogs = { viewModel.requestClearLogs() }
                    )
                }
            }

            // Status Banner Popup
            AnimatedVisibility(
                visible = statusBanner != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Snackbar(
                    containerColor = CyberSurfaceVariant,
                    contentColor = CyberTextPrimary,
                    action = {
                        TextButton(onClick = { viewModel.clearStatusBanner() }) {
                            Text("ঠিক আছে", color = CyberPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                ) {
                    Text(text = statusBanner ?: "")
                }
            }

            // In-app Curfew Fullscreen Overlay
            if (isCurfewLockActive) {
                FullscreenCurfewOverlay(
                    config = curfewConfig,
                    onRequestEmergencyUnlock = { viewModel.requestEmergencyCurfewOverride() }
                )
            }
        }
    }

    // PIN Authentication Dialog
    if (pendingPinAction != null) {
        PinDialog(
            actionTitle = "অ্যাডমিন পিন যাচাই",
            actionDescription = "সুরক্ষা সেটিংস পরিবর্তন করতে ৪-সংখ্যার মাস্টার পিন কোড দিন",
            onVerifyPin = { pin -> viewModel.verifyPin(pin) },
            onSuccess = { viewModel.onPinSuccess() },
            onDismiss = { viewModel.dismissPinDialog() },
            securityQuestion = viewModel.getSecurityQuestion(),
            onVerifyRecoveryAnswer = { ans -> viewModel.verifySecurityAnswer(ans) },
            isLockedOut = viewModel.isLockedOut(),
            lockoutSeconds = viewModel.getRemainingLockoutSeconds()
        )
    }

    // Master PIN Setup Dialog (shown on first launch or when requested)
    if (showSetupPinDialog) {
        SetupPinDialog(
            isInitialSetup = !isPinConfigured,
            onSavePin = { pin, question, answer ->
                viewModel.setupMasterPin(pin, question, answer)
            },
            onDismiss = { viewModel.dismissSetupPinDialog() }
        )
    }
}

@Composable
fun TopHeaderBar(
    isBangla: Boolean,
    isCurfewActive: Boolean,
    isDeviceAdminActive: Boolean,
    onToggleLanguage: () -> Unit
) {
    Surface(
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_safeguard_logo),
                    contentDescription = "Safe Guard Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "SAFE GUARD",
                            color = CyberTextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        if (isCurfewActive) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberDanger)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "LOCKED",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Text(
                        text = if (isBangla) "ফোন কার্ফিউ ও আসক্তি নিরাময়" else "Phone Curfew & Recovery",
                        color = CyberTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Language switch button
                IconButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language",
                        tint = CyberPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun OverviewTabContent(
    isBangla: Boolean,
    curfewConfig: com.example.curfew.CurfewConfig,
    isCurfewActive: Boolean,
    isDeviceAdminActive: Boolean,
    isPinConfigured: Boolean,
    curfewManager: com.example.curfew.CurfewManager,
    onUpdateCurfewConfig: (com.example.curfew.CurfewConfig) -> Unit,
    onQuickTestLock: () -> Unit,
    onLockScreenNow: () -> Unit,
    onRequestActivateAdmin: () -> Unit,
    onNavigateTab: (SafeGuardTab) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Curfew Status Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                if (isCurfewActive) Color(0xFF3B0B18) else Color(0xFF131D33),
                                CyberSurface
                            )
                        )
                    )
                    .border(
                        1.5.dp,
                        if (isCurfewActive) CyberDanger else CyberPrimary.copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCurfewActive) CyberDanger.copy(alpha = 0.2f)
                                else CyberPrimary.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCurfewActive) Icons.Default.Lock else Icons.Default.Bedtime,
                            contentDescription = null,
                            tint = if (isCurfewActive) CyberDanger else CyberPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isCurfewActive)
                            AppStrings.t("curfew_active", isBangla)
                        else if (curfewConfig.isEnabled)
                            AppStrings.t("curfew_scheduled", isBangla)
                        else
                            AppStrings.t("curfew_inactive", isBangla),
                        color = if (isCurfewActive) CyberDanger else CyberTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (isCurfewActive)
                            AppStrings.t("curfew_active_desc", isBangla)
                        else if (curfewConfig.isEnabled)
                            "লক সময়সীমা: ${curfewManager.formatTimeString(curfewConfig.startHour, curfewConfig.startMinute)} থেকে ${curfewManager.formatTimeString(curfewConfig.endHour, curfewConfig.endMinute)}"
                        else
                            AppStrings.t("curfew_inactive_desc", isBangla),
                        color = CyberTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary Toggle Switch & Quick Action
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                onUpdateCurfewConfig(curfewConfig.copy(isEnabled = !curfewConfig.isEnabled))
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (curfewConfig.isEnabled) CyberDanger.copy(alpha = 0.8f) else CyberPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).testTag("toggle_curfew_button")
                        ) {
                            Text(
                                text = if (curfewConfig.isEnabled)
                                    AppStrings.t("btn_turn_off", isBangla)
                                else
                                    AppStrings.t("btn_turn_on", isBangla),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { onNavigateTab(SafeGuardTab.BEDTIME_LOCK) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f).testTag("configure_curfew_button")
                        ) {
                            Text(
                                text = if (isBangla) "সময় পরিবর্তন" else "Edit Schedule",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Quick Instant Actions Bar
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // 1-Min Strict Test Lock
                Button(
                    onClick = onQuickTestLock,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberWarning,
                        contentColor = CyberBackground
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).testTag("quick_test_lock_button")
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = AppStrings.t("btn_test_lock", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                // Instant Screen Lock
                Button(
                    onClick = onLockScreenNow,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberSurfaceVariant,
                        contentColor = CyberPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).testTag("lock_screen_now_button")
                ) {
                    Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = AppStrings.t("btn_lock_screen", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Device Admin Prompt if not enabled
        if (!isDeviceAdminActive) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(CyberDanger.copy(alpha = 0.12f))
                        .border(1.dp, CyberDanger.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(20.dp))
                            Text(
                                text = if (isBangla) "অ্যান্টি-আনইন্সটল সক্রিয় করুন" else "Enable Anti-Uninstall Protection",
                                color = CyberDanger,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isBangla)
                                "ডিভাইস অ্যাডমিন সক্রিয় রাখলে কেউ অ্যাপটি আনইন্সটল করে লক বাইপাস করতে পারবে না।"
                            else
                                "Activate Device Admin to prevent unauthorized uninstallation and protect your curfew schedule.",
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        Button(
                            onClick = onRequestActivateAdmin,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isBangla) "অ্যাডমিন সক্রিয় করুন" else "Activate Admin", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 4 Security Metrics Cards
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = AppStrings.t("stat_curfew_status", isBangla),
                    value = if (isCurfewActive) AppStrings.t("active", isBangla) else if (curfewConfig.isEnabled) AppStrings.t("configured", isBangla) else AppStrings.t("inactive", isBangla),
                    valueColor = if (isCurfewActive) CyberDanger else if (curfewConfig.isEnabled) CyberPrimary else CyberTextMuted,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = AppStrings.t("stat_lock_mode", isBangla),
                    value = if (curfewConfig.isStrictUnbreakableLock) AppStrings.t("strict", isBangla) else AppStrings.t("standard", isBangla),
                    valueColor = if (curfewConfig.isStrictUnbreakableLock) CyberWarning else CyberSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    title = AppStrings.t("stat_admin_status", isBangla),
                    value = if (isDeviceAdminActive) AppStrings.t("active", isBangla) else AppStrings.t("not_configured", isBangla),
                    valueColor = if (isDeviceAdminActive) CyberPrimary else CyberDanger,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = AppStrings.t("stat_pin_status", isBangla),
                    value = if (isPinConfigured) AppStrings.t("configured", isBangla) else AppStrings.t("not_configured", isBangla),
                    valueColor = if (isPinConfigured) CyberSecondary else CyberWarning,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Feature Catalog Hub
        item {
            FeatureCatalogSection(
                isBangla = isBangla,
                onNavigateTab = onNavigateTab
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun MiniAudioPlayerBar(
    playerState: com.example.islamic.PlayerState,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onClick: () -> Unit
) {
    val surahTitle = playerState.activeSurahTitle ?: "সূরা তিলাওয়াত"

    Surface(
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberSecondary.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column {
            if (playerState.totalDurationMs > 0) {
                LinearProgressIndicator(
                    progress = {
                        (playerState.currentPositionMs.toFloat() / playerState.totalDurationMs.toFloat()).coerceIn(0f, 1f)
                    },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                    color = CyberSecondary,
                    trackColor = CyberSurfaceVariant
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CyberSecondary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = CyberSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = surahTitle,
                            color = CyberTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = playerState.activeAudioMode.titleBangla,
                            color = CyberSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPlayPause) {
                        Icon(
                            imageVector = if (playerState.status == AudioPlaybackStatus.PLAYING) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = CyberSecondary
                        )
                    }
                    IconButton(onClick = onStop) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Stop",
                            tint = CyberTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
