package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.curfew.CurfewConfig
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import java.util.Calendar

@Composable
fun BedtimeLockTab(
    curfewConfig: CurfewConfig,
    isLockCurrentlyActive: Boolean,
    onUpdateConfig: (CurfewConfig) -> Unit,
    onRequestEmergencyOverride: () -> Unit
) {
    var isEditingHours by remember { mutableStateOf(false) }

    var startHourStr by remember(curfewConfig.startHour) { mutableStateOf(curfewConfig.startHour.toString()) }
    var startMinStr by remember(curfewConfig.startMinute) { mutableStateOf(curfewConfig.startMinute.toString()) }
    var endHourStr by remember(curfewConfig.endHour) { mutableStateOf(curfewConfig.endHour.toString()) }
    var endMinStr by remember(curfewConfig.endMinute) { mutableStateOf(curfewConfig.endMinute.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                if (isLockCurrentlyActive) Color(0xFF3B0B18) else Color(0xFF131D33),
                                CyberSurface
                            )
                        )
                    )
                    .border(
                        1.dp,
                        if (isLockCurrentlyActive) CyberDanger else CyberPrimary.copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                if (isLockCurrentlyActive) CyberDanger.copy(alpha = 0.2f)
                                else CyberPrimary.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isLockCurrentlyActive) Icons.Default.Lock else Icons.Default.Bedtime,
                            contentDescription = "Bedtime Lock",
                            tint = if (isLockCurrentlyActive) CyberDanger else CyberPrimary,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "পুরো ফোন সিস্টেম লক ও কারফিউ গার্ড",
                        color = CyberTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isLockCurrentlyActive)
                            "⚠️ পুরো ফোন লক রয়েছে! নির্ধারিত সময় শেষ হওয়া মাত্র স্বয়ংক্রিয়ভাবে ফোন খুলে যাবে।"
                        else
                            "যে কোনো নির্দিষ্ট সময়ে পুরো ফোন সিস্টেম লক হয়ে যাবে। ওই নির্দিষ্ট সময় শেষ হওয়ার পর পুরো ফোন স্বয়ংক্রিয়ভাবে খুলে যাবে।",
                        color = if (isLockCurrentlyActive) CyberDanger else CyberTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // Master Switch Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "কার্ফিউ লক সক্রিয় করুন",
                            color = CyberTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "নির্ধারিত সময়ে সাথে সাথে ফুলস্ক্রিন প্রোটেকশন পর্দা নামবে",
                            color = CyberTextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = curfewConfig.isEnabled,
                        onCheckedChange = { isChecked ->
                            onUpdateConfig(curfewConfig.copy(isEnabled = isChecked))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberBackground,
                            checkedTrackColor = CyberPrimary,
                            uncheckedThumbColor = CyberTextMuted,
                            uncheckedTrackColor = CyberSurfaceVariant
                        )
                    )
                }
            }
        }

        // Strict Unbreakable Mode Card (User explicitly requested: চাইলেও যেন কেউ খুলতে না পারে)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (curfewConfig.isStrictUnbreakableLock) Color(0xFF261019) else CyberSurface)
                    .border(
                        1.dp,
                        if (curfewConfig.isStrictUnbreakableLock) CyberDanger.copy(alpha = 0.8f) else CyberBorder,
                        RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberDanger.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = CyberDanger,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "কড়া আনব্রেকেবল লক (Strict Mode)",
                                color = if (curfewConfig.isStrictUnbreakableLock) CyberDanger else CyberTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "সক্রিয় থাকলে নির্ধারিত সময়ের আগে পিন দিয়েও খোলা যাবে না। সময় শেষ হলে তবেই ফোন খুলবে।",
                                color = CyberTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    Switch(
                        checked = curfewConfig.isStrictUnbreakableLock,
                        onCheckedChange = { isStrict ->
                            onUpdateConfig(curfewConfig.copy(isStrictUnbreakableLock = isStrict))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberBackground,
                            checkedTrackColor = CyberDanger,
                            uncheckedThumbColor = CyberTextMuted,
                            uncheckedTrackColor = CyberSurfaceVariant
                        )
                    )
                }
            }
        }

        // Quick Instant Test Lock Action (e.g. 6:40 to 6:41)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberWarning.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = CyberWarning,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "১ মিনিটের তাৎক্ষণিক টেস্ট লক",
                            color = CyberWarning,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "এখনই পরীক্ষা করুন! বর্তমান মিনিট থেকে পরবর্তী ১ মিনিটের জন্য পুরো ফোন সিস্টেম লক হয়ে যাবে। ১ মিনিট সময় শেষ হওয়ার পর পুরো ফোন স্বয়ংক্রিয়ভাবে খুলে যাবে।",
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Button(
                        onClick = {
                            val cal = Calendar.getInstance()
                            val curH = cal.get(Calendar.HOUR_OF_DAY)
                            val curM = cal.get(Calendar.MINUTE)
                            val endM = (curM + 1) % 60
                            val endH = if (curM + 1 >= 60) (curH + 1) % 24 else curH

                            onUpdateConfig(
                                curfewConfig.copy(
                                    isEnabled = true,
                                    startHour = curH,
                                    startMinute = curM,
                                    endHour = endH,
                                    endMinute = endM,
                                    isStrictUnbreakableLock = true
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberWarning,
                            contentColor = CyberBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.LockClock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "১ মিনিটের টেস্ট লক চালু করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Time Schedule Settings
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "লক ও আনলকের নির্ধারিত সময়",
                                color = CyberTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { isEditingHours = !isEditingHours },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberSurfaceVariant,
                                contentColor = CyberPrimary
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = if (isEditingHours) "বাতিল" else "পরিবর্তন", fontSize = 11.sp)
                        }
                    }

                    // Display Time Slots
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyberSurfaceVariant)
                                .padding(14.dp)
                        ) {
                            Column {
                                Text(
                                    text = "লক শুরুর সময়",
                                    color = CyberTextMuted,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format("%02d:%02d", curfewConfig.startHour, curfewConfig.startMinute),
                                    color = CyberWarning,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (curfewConfig.startHour >= 12)
                                        "${if (curfewConfig.startHour == 12) 12 else curfewConfig.startHour - 12}:${String.format("%02d", curfewConfig.startMinute)} PM"
                                    else
                                        "${if (curfewConfig.startHour == 0) 12 else curfewConfig.startHour}:${String.format("%02d", curfewConfig.startMinute)} AM",
                                    color = CyberTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyberSurfaceVariant)
                                .padding(14.dp)
                        ) {
                            Column {
                                Text(
                                    text = "স্বয়ংক্রিয় আনলক সময়",
                                    color = CyberTextMuted,
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = String.format("%02d:%02d", curfewConfig.endHour, curfewConfig.endMinute),
                                    color = CyberSecondary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (curfewConfig.endHour >= 12)
                                        "${if (curfewConfig.endHour == 12) 12 else curfewConfig.endHour - 12}:${String.format("%02d", curfewConfig.endMinute)} PM"
                                    else
                                        "${if (curfewConfig.endHour == 0) 12 else curfewConfig.endHour}:${String.format("%02d", curfewConfig.endMinute)} AM",
                                    color = CyberTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Precise Minute-Level Inputs
                    if (isEditingHours) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyberSurfaceVariant)
                                .padding(14.dp)
                        ) {
                            Text(
                                text = "যেকোনো ঘণ্টা ও মিনিট দিন (২৪ ঘণ্টার ফরম্যাট):",
                                color = CyberTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "লক শুরুর সময়:",
                                color = CyberWarning,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = startHourStr,
                                    onValueChange = { startHourStr = it.take(2) },
                                    label = { Text("ঘণ্টা (0-23)", fontSize = 10.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberWarning,
                                        unfocusedBorderColor = CyberBorder
                                    )
                                )

                                OutlinedTextField(
                                    value = startMinStr,
                                    onValueChange = { startMinStr = it.take(2) },
                                    label = { Text("মিনিট (0-59)", fontSize = 10.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberWarning,
                                        unfocusedBorderColor = CyberBorder
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "আনলক শেষ হওয়ার সময়:",
                                color = CyberSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = endHourStr,
                                    onValueChange = { endHourStr = it.take(2) },
                                    label = { Text("ঘণ্টা (0-23)", fontSize = 10.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberSecondary,
                                        unfocusedBorderColor = CyberBorder
                                    )
                                )

                                OutlinedTextField(
                                    value = endMinStr,
                                    onValueChange = { endMinStr = it.take(2) },
                                    label = { Text("মিনিট (0-59)", fontSize = 10.sp) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberSecondary,
                                        unfocusedBorderColor = CyberBorder
                                    )
                                )
                            }

                            Button(
                                onClick = {
                                    val sh = (startHourStr.toIntOrNull() ?: 23).coerceIn(0, 23)
                                    val sm = (startMinStr.toIntOrNull() ?: 0).coerceIn(0, 59)
                                    val eh = (endHourStr.toIntOrNull() ?: 4).coerceIn(0, 23)
                                    val em = (endMinStr.toIntOrNull() ?: 0).coerceIn(0, 59)

                                    onUpdateConfig(
                                        curfewConfig.copy(
                                            startHour = sh,
                                            startMinute = sm,
                                            endHour = eh,
                                            endMinute = em
                                        )
                                    )
                                    isEditingHours = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CyberPrimary,
                                    contentColor = CyberBackground
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("সময় সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Emergency Override Option (Disabled if strict unbreakable lock is active)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "জরুরি সাময়িক আনলক (Emergency Override)",
                        color = CyberTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (curfewConfig.isStrictUnbreakableLock) {
                        Text(
                            text = "⚠️ কড়া মোড সক্রিয় থাকায় জরুরি আনলক সম্পূর্ণ নিষ্ক্রিয় করা হয়েছে। নির্ধারিত সময় শেষ হওয়ার পরই ফোন স্বয়ংক্রিয়ভাবে আনলক হবে।",
                            color = CyberDanger,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    } else {
                        Text(
                            text = "রাতে জরুরি কাজ বা যোগাযোগের প্রয়োজন হলে অ্যাডমিন পিন ভেরিফাই করে ১৫ মিনিটের জন্য সাময়িক অ্যাক্সেস নেওয়া যাবে।",
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = onRequestEmergencyOverride,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberWarning),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "জরুরি ১৫ মিনিট আনলক", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
