package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.admin.DeviceAdminHelper
import com.example.curfew.CurfewAlarmScheduler
import com.example.curfew.CurfewConfig
import com.example.curfew.CurfewLockActivity
import com.example.curfew.CurfewManager
import com.example.data.local.LockLogEntity
import com.example.data.local.SafeGuardDatabase
import com.example.islamic.AudioMode
import com.example.islamic.HadithBook
import com.example.islamic.IslamicAdvice
import com.example.islamic.IslamicContentRepository
import com.example.islamic.IslamicPoem
import com.example.islamic.PlayerState
import com.example.islamic.QuranAudioManager
import com.example.islamic.QuranSurah
import com.example.security.SecurityManager
import com.example.update.AppUpdateChecker
import com.example.update.AppUpdateInfo
import com.example.util.AppLanguage
import com.example.util.LanguageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SafeGuardTab {
    OVERVIEW,
    BEDTIME_LOCK,
    ISLAMIC_RECOVERY,
    SETTINGS
}

sealed class PinAction {
    object DeactivateAdmin : PinAction()
    object ChangePin : PinAction()
    object EmergencyCurfewOverride : PinAction()
    object ClearLockLogs : PinAction()
}

class SafeGuardViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val securityManager = SecurityManager(context)
    private val database = SafeGuardDatabase.getDatabase(context)
    val curfewManager = CurfewManager(context)
    val quranAudioManager = QuranAudioManager(context)
    val updateChecker = AppUpdateChecker(context)
    val languageManager = LanguageManager(context)

    // Language State (Bangla by default, supports English switch)
    private val _appLanguage = MutableStateFlow(languageManager.getLanguage())
    val appLanguage: StateFlow<AppLanguage> = _appLanguage.asStateFlow()

    // Curfew Bedtime Lock State
    private val _curfewConfig = MutableStateFlow(curfewManager.getCurfewConfig())
    val curfewConfig: StateFlow<CurfewConfig> = _curfewConfig.asStateFlow()

    private val _isCurfewLockActive = MutableStateFlow(curfewManager.isCurfewCurrentlyActive())
    val isCurfewLockActive: StateFlow<Boolean> = _isCurfewLockActive.asStateFlow()

    // Islamic Quran & Audio Player State
    val surahs: List<QuranSurah> = IslamicContentRepository.quranSurahs
    val antiAddictionAdvices: List<IslamicAdvice> = IslamicContentRepository.antiAddictionAdvices
    val hadithBooks: List<HadithBook> = IslamicContentRepository.hadithBooks
    val islamicPoems: List<IslamicPoem> = IslamicContentRepository.islamicPoems
    val playerState: StateFlow<PlayerState> = quranAudioManager.playerState

    private val _selectedAudioMode = MutableStateFlow(AudioMode.ARABIC_ONLY)
    val selectedAudioMode: StateFlow<AudioMode> = _selectedAudioMode.asStateFlow()

    // App Update State
    private val _updateInfo = MutableStateFlow(updateChecker.checkForUpdates())
    val updateInfo: StateFlow<AppUpdateInfo> = _updateInfo.asStateFlow()

    // Device Admin & PIN State
    private val _isDeviceAdminActive = MutableStateFlow(DeviceAdminHelper.isDeviceAdminActive(context))
    val isDeviceAdminActive: StateFlow<Boolean> = _isDeviceAdminActive.asStateFlow()

    private val _isPinConfigured = MutableStateFlow(securityManager.isPinConfigured())
    val isPinConfigured: StateFlow<Boolean> = _isPinConfigured.asStateFlow()

    // Current navigation tab
    private val _currentTab = MutableStateFlow(SafeGuardTab.OVERVIEW)
    val currentTab: StateFlow<SafeGuardTab> = _currentTab.asStateFlow()

    // Dialogs & Security Actions
    private val _pendingPinAction = MutableStateFlow<PinAction?>(null)
    val pendingPinAction: StateFlow<PinAction?> = _pendingPinAction.asStateFlow()

    private val _showSetupPinDialog = MutableStateFlow(!securityManager.isPinConfigured())
    val showSetupPinDialog: StateFlow<Boolean> = _showSetupPinDialog.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    // Lock History Logs from Room DB
    val lockLogs: StateFlow<List<LockLogEntity>> = database.lockLogDao().getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalLogCount: StateFlow<Int> = database.lockLogDao().getTotalLogCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun refreshDeviceAdminStatus() {
        _isDeviceAdminActive.value = DeviceAdminHelper.isDeviceAdminActive(context)
    }

    fun selectTab(tab: SafeGuardTab) {
        _currentTab.value = tab
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    // Hardware device screen lock
    fun lockScreenNow() {
        DeviceAdminHelper.lockDeviceNow(context)
        logEvent("DEVICE_LOCKED", "স্ক্রিন অফ করা হয়েছে", "ইউজার তাৎক্ষণিকভাবে ডিভাইসের স্ক্রিন বন্ধ ও লক করেছেন।")
    }

    // Curfew Bedtime Methods
    fun updateCurfewConfig(config: CurfewConfig) {
        curfewManager.saveCurfewConfig(config)
        _curfewConfig.value = config
        val isActive = curfewManager.isCurfewCurrentlyActive()
        _isCurfewLockActive.value = isActive

        if (config.isEnabled) {
            CurfewAlarmScheduler.scheduleCurfewAlarms(context, config)
            if (isActive) {
                CurfewLockActivity.startLock(context)
                DeviceAdminHelper.lockDeviceNow(context)
                logEvent("CURFEW_STARTED", "কার্ফিউ লক শুরু হয়েছে", "নির্ধারিত সময়সীমা অনুযায়ী পুরো ফোন সিস্টেম লক রয়েছে।")
            } else {
                logEvent("CURFEW_SCHEDULED", "কার্ফিউ শিডিউল সংরক্ষিত", "${curfewManager.formatTimeString(config.startHour, config.startMinute)} থেকে ${curfewManager.formatTimeString(config.endHour, config.endMinute)}")
            }
        } else {
            CurfewAlarmScheduler.cancelCurfewAlarms(context)
            logEvent("CURFEW_DISABLED", "কার্ফিউ লক বন্ধ করা হয়েছে", "ইউজার কার্ফিউ লক নিষ্ক্রিয় করেছেন।")
        }

        _statusBanner.value = if (config.isEnabled) "পুরো ফোন কার্ফিউ লক সক্রিয় করা হয়েছে" else "কার্ফিউ লক বন্ধ করা হয়েছে"
    }

    // 1-minute quick strict test lock helper
    fun testOneMinuteLock() {
        val cal = java.util.Calendar.getInstance()
        val curH = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val curM = cal.get(java.util.Calendar.MINUTE)
        val endM = (curM + 1) % 60
        val endH = if (curM + 1 >= 60) (curH + 1) % 24 else curH

        val newConfig = _curfewConfig.value.copy(
            isEnabled = true,
            startHour = curH,
            startMinute = curM,
            endHour = endH,
            endMinute = endM,
            isStrictUnbreakableLock = true
        )
        updateCurfewConfig(newConfig)

        // Immediately launch full-screen unbreakable lock and hardware device lock
        CurfewLockActivity.startLock(context)
        DeviceAdminHelper.lockDeviceNow(context)
        logEvent("TEST_LOCK_1MIN", "১-মিনিটের কড়া টেস্ট লক সক্রিয়", "১ মিনিটের জন্য ফোন লক কার্যকর করা হয়েছে ($curH:${String.format("%02d", curM)} থেকে $endH:${String.format("%02d", endM)})।")
        _statusBanner.value = "১ মিনিটের কড়া টেস্ট লক সক্রিয় করা হয়েছে ($curH:${String.format("%02d", curM)} থেকে $endH:${String.format("%02d", endM)})"
    }

    fun requestEmergencyCurfewOverride() {
        if (_isPinConfigured.value) {
            _pendingPinAction.value = PinAction.EmergencyCurfewOverride
        } else {
            curfewManager.grantEmergencyUnlock(15)
            _isCurfewLockActive.value = false
            logEvent("EMERGENCY_UNLOCK", "১৫ মিনিট জরুরি আনলক", "কার্ফিউ চলাকালে জরুরি অ্যাক্সেস দেওয়া হয়েছে।")
        }
    }

    // PIN Authentication
    fun verifyPin(pin: String): Boolean {
        return securityManager.verifyPin(pin)
    }

    fun onPinSuccess() {
        val action = _pendingPinAction.value
        _pendingPinAction.value = null
        when (action) {
            is PinAction.DeactivateAdmin -> executeDeactivateAdmin()
            is PinAction.ChangePin -> {
                _showSetupPinDialog.value = true
            }
            is PinAction.EmergencyCurfewOverride -> {
                curfewManager.grantEmergencyUnlock(15)
                _isCurfewLockActive.value = false
                _statusBanner.value = "১৫ মিনিটের জন্য জরুরি অ্যাক্সেস দেওয়া হয়েছে"
                logEvent("EMERGENCY_UNLOCK", "জরুরি আনলক অনুমোদন", "মাস্টার পিন ভেরিফিকেশনের মাধ্যমে ১৫ মিনিটের জন্য ফোন আনলক।")
            }
            is PinAction.ClearLockLogs -> clearLogsInternal()
            null -> {}
        }
    }

    fun dismissPinDialog() {
        _pendingPinAction.value = null
    }

    // Setup Master PIN
    fun setupMasterPin(pin: String, question: String, answer: String): Boolean {
        val success = securityManager.setMasterPin(pin, question, answer)
        if (success) {
            _isPinConfigured.value = true
            _showSetupPinDialog.value = false
            _statusBanner.value = "অ্যাডমিন মাস্টার পিন সফলভাবে সংরক্ষিত হয়েছে"
            logEvent("PIN_SET", "মাস্টার পিন সেট করা হয়েছে", "অ্যাডমিন সিকিউরিটি পিন কনফিগারেশন সম্পন্ন।")
        }
        return success
    }

    fun dismissSetupPinDialog() {
        if (_isPinConfigured.value) {
            _showSetupPinDialog.value = false
        }
    }

    fun requestChangePin() {
        if (_isPinConfigured.value) {
            _pendingPinAction.value = PinAction.ChangePin
        } else {
            _showSetupPinDialog.value = true
        }
    }

    fun requestDeactivateAdmin() {
        if (_isPinConfigured.value) {
            _pendingPinAction.value = PinAction.DeactivateAdmin
        } else {
            executeDeactivateAdmin()
        }
    }

    private fun executeDeactivateAdmin() {
        DeviceAdminHelper.deactivateAdmin(context)
        _isDeviceAdminActive.value = false
        _statusBanner.value = "ডিভাইস অ্যাডমিন সুরক্ষা বন্ধ করা হয়েছে"
        logEvent("ADMIN_DEACTIVATED", "ডিভাইস অ্যাডমিন বন্ধ", "অ্যান্টি-আনইন্সটল সুরক্ষা নিষ্ক্রিয় করা হয়েছে।")
    }

    fun requestClearLogs() {
        if (_isPinConfigured.value) {
            _pendingPinAction.value = PinAction.ClearLockLogs
        } else {
            clearLogsInternal()
        }
    }

    private fun clearLogsInternal() {
        viewModelScope.launch(Dispatchers.IO) {
            database.lockLogDao().clearAll()
            _statusBanner.value = "লক হিস্ট্রি মুছে ফেলা হয়েছে"
        }
    }

    private fun logEvent(type: String, title: String, details: String) {
        viewModelScope.launch(Dispatchers.IO) {
            database.lockLogDao().insertLog(
                LockLogEntity(
                    eventType = type,
                    titleBangla = title,
                    detailsBangla = details
                )
            )
        }
    }

    fun getSecurityQuestion(): String {
        return securityManager.getSecurityQuestion()
    }

    fun verifySecurityAnswer(answer: String): Boolean {
        return securityManager.verifySecurityAnswer(answer)
    }

    fun isLockedOut(): Boolean {
        return securityManager.isLockedOut()
    }

    fun getRemainingLockoutSeconds(): Long {
        return securityManager.getRemainingLockoutSeconds()
    }

    // Islamic Quran Audio Player Methods
    fun setAudioMode(mode: AudioMode) {
        _selectedAudioMode.value = mode
    }

    fun onPlaySurah(surah: QuranSurah, mode: AudioMode = _selectedAudioMode.value) {
        quranAudioManager.playOrPauseSurah(surah, mode)
    }

    fun onDownloadSurah(surah: QuranSurah, mode: AudioMode = _selectedAudioMode.value) {
        quranAudioManager.downloadSurahAudio(surah, mode) { success ->
            _statusBanner.value = if (success) "${surah.nameBangla} (${mode.titleBangla}) ডাউনলোড সফল হয়েছে" else "ডাউনলোড ব্যর্থ হয়েছে"
        }
    }

    fun onDeleteDownloadedSurah(surahNumber: Int, mode: AudioMode = _selectedAudioMode.value) {
        quranAudioManager.deleteDownloadedSurah(surahNumber, mode)
        _statusBanner.value = "ডাউনলোড ফাইল মুছে ফেলা হয়েছে"
    }

    // App Update
    fun checkAppUpdateNow() {
        val info = updateChecker.checkForUpdates()
        _updateInfo.value = info
        _statusBanner.value = if (info.isUpdateAvailable) "নতুন আপডেট পাওয়া গেছে!" else "আপনার অ্যাপটি আপ-টু-ডেট রয়েছে"
    }

    fun openUpdateLink() {
        updateChecker.openUpdatePage(_updateInfo.value.downloadUrl)
    }

    // Language switch
    fun setLanguage(language: AppLanguage) {
        languageManager.setLanguage(language)
        _appLanguage.value = language
        _statusBanner.value = if (language == AppLanguage.BANGLA) "ভাষা বাংলায় পরিবর্তন করা হয়েছে" else "Language changed to English"
    }

    override fun onCleared() {
        super.onCleared()
        quranAudioManager.stopPlayback()
    }
}
