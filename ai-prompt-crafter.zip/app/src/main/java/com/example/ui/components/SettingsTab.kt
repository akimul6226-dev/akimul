package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.LockLogEntity
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSecondary
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarning
import com.example.update.AppUpdateInfo
import com.example.util.AppLanguage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsTab(
    isBangla: Boolean,
    isDeviceAdminActive: Boolean,
    onRequestActivateAdmin: () -> Unit,
    onRequestDeactivateAdmin: () -> Unit,
    isPinConfigured: Boolean,
    onRequestChangePin: () -> Unit,
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
    updateInfo: AppUpdateInfo,
    onCheckUpdate: () -> Unit,
    onOpenUpdateLink: () -> Unit,
    lockLogs: List<LockLogEntity>,
    onRequestClearLogs: () -> Unit
) {
    val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Device Admin Anti-Uninstall
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isDeviceAdminActive) CyberPrimary.copy(alpha = 0.5f) else CyberDanger.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isDeviceAdminActive) CyberPrimary.copy(alpha = 0.15f)
                                    else CyberDanger.copy(alpha = 0.15f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = if (isDeviceAdminActive) CyberPrimary else CyberDanger,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBangla) "অ্যান্টি-আনইন্সটল ডিভাইস অ্যাডমিন" else "Anti-Uninstall Device Admin",
                                color = CyberTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isDeviceAdminActive)
                                    (if (isBangla) "সক্রিয়: অ্যাপটি অননুমোদিত মোছা যাবে না" else "Active: App is tamper-protected")
                                else
                                    (if (isBangla) "নিষ্ক্রিয়: যে কেউ অ্যাপটি মুছে ফেলতে পারে" else "Inactive: Anyone can uninstall the app"),
                                color = if (isDeviceAdminActive) CyberPrimary else CyberDanger,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isBangla)
                            "ডিভাইস অ্যাডমিনের মাধ্যমে এই অ্যাপটি আনইন্সটল প্রতিরোধ করা হয়। এছাড়া নির্দিষ্ট সময়ে ফোন অবিলম্বে লক করার হার্ডওয়্যার পারমিশন ব্যবহৃত হয়।"
                        else
                            "Device Administrator prevents tampering/uninstallation and allows instant hardware screen lock during curfew.",
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isDeviceAdminActive) {
                        Button(
                            onClick = onRequestActivateAdmin,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberDanger,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("activate_admin_button")
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBangla) "ডিভাইস অ্যাডমিন সক্রিয় করুন" else "Activate Device Admin",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = onRequestDeactivateAdmin,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberTextMuted),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("deactivate_admin_button")
                        ) {
                            Text(
                                text = if (isBangla) "অ্যাডমিন বন্ধ করুন (পিন প্রয়োজন)" else "Deactivate Admin (Requires PIN)",
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Section: Master PIN
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CyberSecondary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = CyberSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBangla) "মাস্টার পিন সিকিউরিটি" else "Master PIN Security",
                                color = CyberTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isPinConfigured)
                                    (if (isBangla) "পিন সুরক্ষিত (SHA-256 এনক্রিপ্টেড)" else "Configured (Encrypted)")
                                else
                                    (if (isBangla) "পিন সেট করা নেই" else "Not set"),
                                color = if (isPinConfigured) CyberSecondary else CyberWarning,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isBangla)
                            "কার্ফিউ সেটিংস পরিবর্তন, জরুরি আনলক এবং অ্যাডমিন নিষ্ক্রিয় করার জন্য এই ৪-সংখ্যার মাস্টার পিন কোড প্রয়োজন।"
                        else
                            "This 4-digit PIN is required to change curfew schedules, emergency override, and disable device protections.",
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onRequestChangePin,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberSecondary,
                            contentColor = CyberBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("change_pin_button")
                    ) {
                        Text(
                            text = if (isPinConfigured)
                                (if (isBangla) "মাস্টার পিন পরিবর্তন করুন" else "Change Master PIN")
                            else
                                (if (isBangla) "নতুন পিন সেট করুন" else "Set Master PIN"),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section: Language Switcher
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyberPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column {
                            Text(
                                text = if (isBangla) "ভাষা নির্বাচন (Language)" else "App Language",
                                color = CyberTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (currentLanguage == AppLanguage.BANGLA) "বর্তমান: বাংলা" else "Current: English",
                                color = CyberTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onToggleLanguage,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("toggle_language_button")
                    ) {
                        Text(
                            text = if (currentLanguage == AppLanguage.BANGLA) "English" else "বাংলা",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section: App Version & Updates
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyberPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SystemUpdate,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isBangla) "অ্যাপ সংস্করণ ও আপডেট" else "App Version & Updates",
                                color = CyberTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "v${updateInfo.currentVersion}",
                                color = CyberTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        OutlinedButton(
                            onClick = onCheckUpdate,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(if (isBangla) "চেক করুন" else "Check", fontSize = 11.sp)
                        }
                    }

                    if (updateInfo.isUpdateAvailable) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onOpenUpdateLink,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberWarning,
                                contentColor = CyberBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isBangla) "নতুন সংস্করণ ডাউনলোড করুন (${updateInfo.latestVersion})" else "Download Update (${updateInfo.latestVersion})",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Section: Phone Lock Event History Logs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = CyberPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (isBangla) "ফোন লক হিস্ট্রি (${lockLogs.size})" else "Lock Event History (${lockLogs.size})",
                        color = CyberTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (lockLogs.isNotEmpty()) {
                    TextButton(onClick = onRequestClearLogs) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isBangla) "মুছে ফেলুন" else "Clear", color = CyberDanger, fontSize = 11.sp)
                    }
                }
            }
        }

        if (lockLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberSurface)
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isBangla) "এখনও কোনো লক হিস্ট্রি রেকর্ড নেই।" else "No lock event records yet.",
                        color = CyberTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            items(lockLogs, key = { it.id }) { log ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberSurface)
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = log.titleBangla,
                                color = when (log.eventType) {
                                    "CURFEW_STARTED", "TEST_LOCK_1MIN" -> CyberDanger
                                    "EMERGENCY_UNLOCK" -> CyberWarning
                                    "DEVICE_LOCKED" -> CyberPrimary
                                    else -> CyberSecondary
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = dateFormat.format(Date(log.timestamp)),
                                color = CyberTextMuted,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = log.detailsBangla,
                            color = CyberTextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
