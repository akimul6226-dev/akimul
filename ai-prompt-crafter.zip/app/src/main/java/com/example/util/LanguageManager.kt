package com.example.util

import android.content.Context
import android.content.SharedPreferences

enum class AppLanguage {
    BANGLA,
    ENGLISH
}

class LanguageManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("safeguard_lang_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LANGUAGE = "selected_language"
    }

    fun getLanguage(): AppLanguage {
        val saved = prefs.getString(KEY_LANGUAGE, AppLanguage.BANGLA.name)
        return try {
            AppLanguage.valueOf(saved ?: AppLanguage.BANGLA.name)
        } catch (e: Exception) {
            AppLanguage.BANGLA
        }
    }

    fun setLanguage(language: AppLanguage) {
        prefs.edit().putString(KEY_LANGUAGE, language.name).apply()
    }
}

object AppStrings {
    fun t(key: String, isBangla: Boolean): String {
        return if (isBangla) banglaStrings[key] ?: key else englishStrings[key] ?: key
    }

    private val banglaStrings = mapOf(
        // Tabs
        "tab_overview" to "শিল্ড",
        "tab_bedtime" to "কার্ফিউ ও ফোন লক",
        "tab_quran" to "কুরআন ও গাইড",
        "tab_settings" to "কন্ট্রোল ও পিন",
        "tab_logs" to "লক হিস্ট্রি",
        "tab_anti_uninstall" to "অ্যান্টি-আনইন্সটল",

        // Overview
        "app_title" to "Safe Guard",
        "app_subtitle" to "ডিজিটাল সুরক্ষা ও আসক্তি মুক্তি গার্ডিয়ান",
        "curfew_active" to "ফোন কার্ফিউ লক সক্রিয়",
        "curfew_scheduled" to "কার্ফিউ শিডিউল সংরক্ষিত",
        "curfew_inactive" to "কার্ফিউ লক বন্ধ রয়েছে",
        "curfew_active_desc" to "নির্ধারিত কার্ফিউ সময় চলছে। ফোন স্বয়ংক্রিয়ভাবে লক করা হয়েছে।",
        "curfew_scheduled_desc" to "নির্ধারিত সময় শুরু হওয়া মাত্রই পুরো ফোন লক হয়ে যাবে।",
        "curfew_inactive_desc" to "কার্ফিউ লক চালু করুন যাতে গভীর রাতে বা নির্দিষ্ট সময়ে ফোন ব্যবহার বন্ধ থাকে।",

        "stat_curfew_status" to "কার্ফিউ লক",
        "stat_admin_status" to "ডিভাইস অ্যাডমিন",
        "stat_pin_status" to "মাস্টার পিন",
        "stat_lock_mode" to "লক মোড",
        "active" to "সক্রিয়",
        "inactive" to "নিষ্ক্রিয়",
        "configured" to "সুরক্ষিত",
        "not_configured" to "সেটআপ প্রয়োজন",
        "strict" to "কড়া মোড",
        "standard" to "স্ট্যান্ডার্ড",

        // Quick Actions
        "btn_test_lock" to "১-মিনিট টেস্ট লক",
        "btn_lock_screen" to "স্ক্রিন অফ করুন",
        "btn_turn_on" to "কার্ফিউ চালু করুন",
        "btn_turn_off" to "কার্ফিউ বন্ধ করুন",

        // Features Grid
        "feature_hub_title" to "ফোন লক ও প্রয়োজনীয় সুবিধাসমূহ",
        "feature_hub_desc" to "ফোন আসক্তি বন্ধ করতে ও সুরক্ষায় প্রতিটি ফিচার স্বাধীনভাবে ব্যবহার করুন।",
        "feat_curfew_title" to "🌙 নাইট কার্ফিউ ও ফোন লক",
        "feat_curfew_desc" to "নির্ধারিত সময়ে (যেমন রাত ১১টা থেকে ভোর ৪টা) পুরো ফোন স্বয়ংক্রিয়ভাবে লক থাকবে।",
        "feat_quran_title" to "📖 অডিও কুরআন ও তিলাওয়াত",
        "feat_quran_desc" to "অর্থসহ তিলাওয়াত শুনুন এবং অফলাইনে শোনার জন্য ডাউনলোড করুন।",
        "feat_recovery_title" to "🤲 আসক্তি মুক্তির ইসলামিক গাইড",
        "feat_recovery_desc" to "দৃষ্টি সংযম, আমল ও প্রলোভন দমনের হাদিস ও কুরআনিক নির্দেশনা।",
        "feat_anti_uninstall_title" to "🔒 অ্যান্টি-আনইন্সটল ও পিন লক",
        "feat_anti_uninstall_desc" to "অ্যাপটি আনইন্সটল বা সেটিংস পরিবর্তন করতে গোপন পিন কোড প্রয়োজন।",
        "feat_logs_title" to "📊 ফোন লক ইভেন্ট হিস্ট্রি",
        "feat_logs_desc" to "কখন ফোন লক ও আনলক করা হয়েছে তার রেকর্ড।",

        // Curfew
        "curfew_title" to "নাইট কার্ফিউ ও ফোন লক শিডিউল",
        "curfew_desc" to "নির্দিষ্ট সময়ে ফোন স্বয়ংক্রিয়ভাবে লক করে গভীর রাতে ফোন আসক্তি চিরতরে বন্ধ করুন।",
        "curfew_enable" to "কার্ফিউ লক সক্রিয় করুন",
        "curfew_enable_desc" to "নির্ধারিত সময়ে ফুলস্ক্রিন পর্দা লক ও ডিভাইস স্ক্রিন লক চালু হবে",
        "curfew_start" to "লক শুরুর সময়",
        "curfew_end" to "আনলক হওয়ার সময়",
        "curfew_strict_title" to "কড়া লক মোড (Strict Unbreakable Mode)",
        "curfew_strict_desc" to "চাইলেও নির্ধারিত সময়ের আগে ফোন খোলা যাবে না। সময় শেষ হলে তবেই ফোন খুলবে।",
        "curfew_emergency" to "জরুরি আনলক (Emergency Override)",
        "curfew_emergency_desc" to "জরুরি প্রয়োজনে মাস্টার পিন দিয়ে ১৫ মিনিটের জন্য ফোন সাময়িক আনলক করুন।",

        // Quran
        "quran_header" to "পবিত্র কুরআন ও অন্তরের প্রশান্তি",
        "quran_sub" to "তিলাওয়াত শুনুন ও অফলাইনে শোনার জন্য সেভ রাখুন",
        "play" to "শুনুন",
        "pause" to "থামুন",
        "download" to "ডাউনলোড",
        "downloaded" to "অফলাইন",
        "verses" to "আয়াত",

        // Settings & Language
        "lang_switch_title" to "ভাষা পরিবর্তন (Language Switch)",
        "lang_current" to "বর্তমান ভাষা: বাংলা",
        "lang_change_to_en" to "English এ পরিবর্তন করুন",
        "lang_change_to_bn" to "বাংলায় পরিবর্তন করুন",
        "update_check" to "আপডেট চেক করুন",
        "version" to "ভার্সন",
        "change_pin" to "মাস্টার পিন পরিবর্তন",
        "device_admin_title" to "অ্যান্টি-আনইন্সটল ডিভাইস অ্যাডমিন",
        "device_admin_active_desc" to "ডিভাইস অ্যাডমিন সক্রিয়। পিন ছাড়া অ্যাপটি মোছা বা বন্ধ করা যাবে না।",
        "device_admin_inactive_desc" to "ডিভাইস অ্যাডমিন সক্রিয় করুন যাতে কেউ অ্যাপটি আনইন্সটল করতে না পারে।"
    )

    private val englishStrings = mapOf(
        // Tabs
        "tab_overview" to "Shield",
        "tab_bedtime" to "Phone Lock",
        "tab_quran" to "Quran & Guide",
        "tab_settings" to "Control & PIN",
        "tab_logs" to "Lock History",
        "tab_anti_uninstall" to "Anti-Uninstall",

        // Overview
        "app_title" to "Safe Guard",
        "app_subtitle" to "Phone Curfew & Digital Lifestyle Guardian",
        "curfew_active" to "Phone Curfew Lock Active",
        "curfew_scheduled" to "Curfew Schedule Armed",
        "curfew_inactive" to "Curfew Lock Inactive",
        "curfew_active_desc" to "Curfew hours are in effect. Phone is securely locked.",
        "curfew_scheduled_desc" to "The phone will automatically lock when curfew starts.",
        "curfew_inactive_desc" to "Enable curfew to eliminate late-night screen addiction.",

        "stat_curfew_status" to "Curfew Lock",
        "stat_admin_status" to "Device Admin",
        "stat_pin_status" to "Master PIN",
        "stat_lock_mode" to "Lock Mode",
        "active" to "Active",
        "inactive" to "Inactive",
        "configured" to "Secured",
        "not_configured" to "Setup Needed",
        "strict" to "Strict Lock",
        "standard" to "Standard",

        // Quick Actions
        "btn_test_lock" to "1-Min Test Lock",
        "btn_lock_screen" to "Lock Screen Now",
        "btn_turn_on" to "Enable Curfew",
        "btn_turn_off" to "Disable Curfew",

        // Features Grid
        "feature_hub_title" to "Phone Lock & Protective Features",
        "feature_hub_desc" to "Independent modules designed to break phone habits and secure your device.",
        "feat_curfew_title" to "🌙 Night Curfew & Phone Lock",
        "feat_curfew_desc" to "Restricts phone usage during scheduled hours (e.g. 11 PM to 4 AM).",
        "feat_quran_title" to "📖 Audio Quran & Translations",
        "feat_quran_desc" to "Listen to beautiful recitations with translations and download for offline.",
        "feat_recovery_title" to "🤲 Anti-Addiction Islamic Guidance",
        "feat_recovery_desc" to "Quranic wisdom, daily sunnah, and emergency prayers against temptations.",
        "feat_anti_uninstall_title" to "🔒 Anti-Uninstall & Master PIN",
        "feat_anti_uninstall_desc" to "Prevents bypassing or removing the app without entering your PIN.",
        "feat_logs_title" to "📊 Lock Event History",
        "feat_logs_desc" to "Chronological log of phone lock and curfew events.",

        // Curfew
        "curfew_title" to "Night Curfew & Bedtime Lockdown",
        "curfew_desc" to "Automatically locks screen usage to eliminate late-night screen addiction.",
        "curfew_enable" to "Enable Curfew Lockdown",
        "curfew_enable_desc" to "Full-screen lock overlay and hardware screen lock activate during chosen hours",
        "curfew_start" to "Lock Start Time",
        "curfew_end" to "Auto-Unlock Time",
        "curfew_strict_title" to "Strict Unbreakable Mode",
        "curfew_strict_desc" to "Cannot be unlocked until the set time expires, even with PIN. Unlocks automatically when time ends.",
        "curfew_emergency" to "Emergency Override",
        "curfew_emergency_desc" to "Temporarily unlocks for 15 minutes by verifying your administrator PIN.",

        // Quran
        "quran_header" to "Holy Quran & Peace of Mind",
        "quran_sub" to "Listen to recitation and download for offline access",
        "play" to "Play",
        "pause" to "Pause",
        "download" to "Download",
        "downloaded" to "Offline",
        "verses" to "Verses",

        // Settings & Language
        "lang_switch_title" to "Language Settings",
        "lang_current" to "Current Language: English",
        "lang_change_to_en" to "Switch to English",
        "lang_change_to_bn" to "Switch to Bangla (বাংলা)",
        "update_check" to "Check for Updates",
        "version" to "Version",
        "change_pin" to "Change Master PIN",
        "device_admin_title" to "Anti-Uninstall Device Admin",
        "device_admin_active_desc" to "Device Admin active. App cannot be uninstalled or stopped without PIN.",
        "device_admin_inactive_desc" to "Activate Device Admin to prevent unauthorized uninstallation."
    )
}
